var class_cidade =
[
    [ "getValor", "class_cidade.html#ab0b7d4ceac2e91112ecfdbf2b6e14795", null ],
    [ "setValor", "class_cidade.html#adbd5a4f0fc90d56f0eb352057251b173", null ]
];
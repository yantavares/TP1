var class_duracao =
[
    [ "getValor", "class_duracao.html#a5fd6f8ad02e0daa5b40341a27919c565", null ],
    [ "setValor", "class_duracao.html#adbac25345a732a7ef54c4427ff0a4584", null ]
];
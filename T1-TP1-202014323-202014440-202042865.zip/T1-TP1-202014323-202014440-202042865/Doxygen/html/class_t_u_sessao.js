var class_t_u_sessao =
[
    [ "run", "class_t_u_sessao.html#a8b7da304bdc9a78148ee32742b65ec31", null ]
];
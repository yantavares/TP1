var class_avaliacao =
[
    [ "getCodigo", "class_avaliacao.html#a0df9a81c3f396e6a0a076fff5ed089d7", null ],
    [ "getDescricao", "class_avaliacao.html#a3f6306dacf81489e86e171ad0ce03d99", null ],
    [ "getNota", "class_avaliacao.html#a73249b0a7330dfadc88c287fd71d7693", null ],
    [ "setCodigo", "class_avaliacao.html#a305204d8f423cc9f84d2cfbe48270eff", null ],
    [ "setDescricao", "class_avaliacao.html#a827d7be35e1b5473c753156c06833a58", null ],
    [ "setNota", "class_avaliacao.html#a04171aae087a6ef045dabaff834572df", null ]
];
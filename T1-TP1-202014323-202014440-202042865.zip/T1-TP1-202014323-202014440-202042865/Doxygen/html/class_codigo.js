var class_codigo =
[
    [ "getValor", "class_codigo.html#ae7dad73e010b3760cbd9310336c19aa2", null ],
    [ "setValor", "class_codigo.html#a1b28a1c462bed10a26f6e3976de785ca", null ]
];
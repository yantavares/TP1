var class_titulo =
[
    [ "getValor", "class_titulo.html#af3422b93c0a48089861f3ee4d705fb5f", null ],
    [ "setValor", "class_titulo.html#a04b498d233424148b881152898cc9d2f", null ]
];
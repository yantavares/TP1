var class_idioma =
[
    [ "getValor", "class_idioma.html#a516a565f8a53da05a465fdeee10af6ba", null ],
    [ "setValor", "class_idioma.html#af40ccb2305a92e8357cd4c6c1a884fb5", null ]
];
var class_nota =
[
    [ "getValor", "class_nota.html#abf2bac0c08529c4f2ccbd75710b4cc95", null ],
    [ "setValor", "class_nota.html#abfcc1a0e6924f38b19598acb9bd58001", null ]
];
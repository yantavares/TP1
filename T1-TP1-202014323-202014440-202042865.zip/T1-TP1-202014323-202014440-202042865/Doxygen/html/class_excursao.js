var class_excursao =
[
    [ "getCidade", "class_excursao.html#a4fa210b6bbd2a3a587c5a428b660b64a", null ],
    [ "getCodigo", "class_excursao.html#a6dff85123ae09e5df1f5482fe1daa851", null ],
    [ "getDescricao", "class_excursao.html#a37bd96e96513d085c5e21c28b1116acf", null ],
    [ "getDuracao", "class_excursao.html#aa570f535ff7f0bb8c1215eaabd0f2ac7", null ],
    [ "getEndereco", "class_excursao.html#a0e77aa38c997c8a0727d1b8f18461c8f", null ],
    [ "getNota", "class_excursao.html#a27f086ea01433f0e86097b3ee5a6a0ec", null ],
    [ "getTitulo", "class_excursao.html#a1738a80ce7f1aa4583289995a024ed15", null ],
    [ "setCidade", "class_excursao.html#ac33430c5c74cbc928bc55ee566b10146", null ],
    [ "setCodigo", "class_excursao.html#aa504b928fa27683eda5a3c4bb4b13d3d", null ],
    [ "setDescricao", "class_excursao.html#a594a39dbb902ee00a639c700238591d7", null ],
    [ "setDuracao", "class_excursao.html#ae9ade1ffdc638bb66814709886c8bbf9", null ],
    [ "setEndereco", "class_excursao.html#ab67c8d741695159da5f6bc1d2391e0c8", null ],
    [ "setNota", "class_excursao.html#a721d236eebe6438a973ed3c43061ca4a", null ],
    [ "setTitulo", "class_excursao.html#a8ce25e44f4ed0fb59515786bfb5718b5", null ]
];
var class_data =
[
    [ "getValor", "class_data.html#a2d040be2799c23a0a3f745613a70bb43", null ],
    [ "setValor", "class_data.html#a0b2499e388847b482e2ecb5f3d7b541c", null ]
];
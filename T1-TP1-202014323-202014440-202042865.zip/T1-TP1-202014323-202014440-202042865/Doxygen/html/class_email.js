var class_email =
[
    [ "getValor", "class_email.html#a573b7a1f21085bbb13cf6ec4dd802ecc", null ],
    [ "setValor", "class_email.html#a5148a6dcb03d12577ea56ccfd344d1c2", null ]
];
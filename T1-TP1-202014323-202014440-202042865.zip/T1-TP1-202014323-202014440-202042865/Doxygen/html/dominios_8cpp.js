var dominios_8cpp =
[
    [ "luhn", "dominios_8cpp.html#a9678b9d998e95c50d551bcefedfbe5d2", null ]
];
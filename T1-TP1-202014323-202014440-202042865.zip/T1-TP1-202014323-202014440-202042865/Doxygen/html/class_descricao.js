var class_descricao =
[
    [ "getValor", "class_descricao.html#a48e45f40d40a338ddc0f34f61f648be2", null ],
    [ "setValor", "class_descricao.html#a0845a285f9856f2cf781cd1d599a8047", null ]
];
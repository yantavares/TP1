var searchData=
[
  ['idioma_0',['Idioma',['../class_idioma.html',1,'']]]
];

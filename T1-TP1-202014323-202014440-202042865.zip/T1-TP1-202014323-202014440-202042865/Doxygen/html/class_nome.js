var class_nome =
[
    [ "getValor", "class_nome.html#ac8881234a0e2d0ddff4fb689ceb256eb", null ],
    [ "setValor", "class_nome.html#ae0d51febff983d63cefe686085c68461", null ]
];
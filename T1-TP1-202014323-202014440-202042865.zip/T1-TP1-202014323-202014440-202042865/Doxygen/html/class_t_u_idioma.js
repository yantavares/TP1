var class_t_u_idioma =
[
    [ "run", "class_t_u_idioma.html#ae09ee051271e21ad675d5a34f0aaa1ea", null ]
];